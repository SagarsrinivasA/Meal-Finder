import React from 'react';

function Display(){
    return (
        <div>
            <h1>Display</h1>
        </div>
    );
}

export default Display;