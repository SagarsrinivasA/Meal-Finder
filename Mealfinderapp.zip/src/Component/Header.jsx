import React from 'react'

export const Header = () => {
  return (
    <h1 className="brand">
    Meal Finder
  </h1>
  )
}