import logo from './logo.svg';
import './App.css';
import { Header } from './Component/Header';
import  From  from './Component/From';

function App() {
  return (
   <section>
     <div className='contaner'>
       <Header/>
       <From/>
     </div>
   </section>
  );
}

export default App;
